﻿=== Cool Timeline PRO ===

Contributors:CoolHappy

Donate link: http://www.cooltimeline.com

Tags:timelines, wp timeline,responsive timeline,timeline,time,simple timeline,timeline for wordpress ,timeline responsive,Lifestream,history,time,stage,life,achievements

Requires at least:4.0

Stable tag:2.6

Tested up to:5.0



== Description ==

Cool Timeline Pro is an advanced timeline plugin that creates responsive vertical storyline automatically in chronological order based on the year and date of your posts. Use Cool Timeline pro WordPress plugin to showcase your life or your company story in a vertical timeline format.



== The plugin is used to create:-  ==

•	Awesome Company Timeline

•	 Cool Timeline

•	Program  History

•	Your Company Storyline

•	Events  Timeline

•	 Life Stories/Timeline

•	 Life Achievements 

•	 Personal Timeline





== Cool features of Cool Timeline Pro:- ==





•	Create Multiple Timeline Stories  -  Create unlimited timeline stories inside your WordPress website or blog.

•	Timeline Scrolling Navigation - Quickly and easily navigate your timeline with a beautiful scrolling navigation inside your timeline.

•	Historical Dates -  Allow you to set dates between the years 1850-2020.

•	Stories Content Format - Add different type of content  like Video, Slideshow, Image in your story.

•	Stories Category Management :-  Add stories in specific category.

•	Advanced Style Options - Customize with your own colors, styles.

•	Story Single Page – Custom single story page.

•	Animation Effects – Add animation effects on timeline scroll.

•	Stories Images in popup – Display stories images in popup.

•	Stories Images Slideshow  - Add images slideshow in stories.

•	Related Stories :- View other stories of timeline quickly on single story page.

•	Mobile Compatibility View 

•	Use via shortcode

•	Easy installation – purchase, download the zip, read the docs

•	Compatible with all major browsers, including IE – compatible from IE9 to IE11, Chrome, Safari and Firefox





== ChangeLog ==
15 September 2016: (version 1.5)

- Added :Horizontal timeline.
- Added :Content timeline
- Added :Icons for timeline.
- Fixed : minor bug fixings

10  September 2016: (version 1.4)
- custom styling bug fixings

29 August 2016: (version 1.3)

- Added : Single sided timeline layout.
- Added :Timeline multiple skins(Light,dark,default).
- Added :stories Pagination feature.
- Added :added year disable feature in settings panel.
- Improved :Overall view of timeline
- Improved : HTML and CSS of timeline.
- Updated:Shortcode generator with layout and skin features.
- Fixed:minor bug fixings.
- Fixed: Minor CSS fixes.

11 August 2016: (version 1.2)

- Added: the time option to set the story time.

- Added: the title color option to set the story title color.

- Added: Created plugin transation file.

- Updated: Extended story year from 1850 to 1700.

- Updated: Timeline z-index with fixed menu bar.

- Fixed: Extra space with Full HTML option.

- Fixed: Story date translation issue.

- Fixed: Minor CSS fixes.

- Updated: Minor changes.



15 July 2016: (version 1.1)

- Improved features, small errors fixed



14 July 2016: (version 1.0)

- Version 1.0 Initial Release