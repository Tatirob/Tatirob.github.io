
			</div><!-- end dashboard content -->

		</div><!-- end dashboard holder -->

		<?php do_action( 'wxr_importer.ui.footer' ) ?>

	</div><!-- end app -->

</div>

<?php

// Don't load the admin footer, as it's loaded for us later.