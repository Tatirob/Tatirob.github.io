<?php

if ( ! defined( 'ABSPATH' ) ) exit;

if( !class_exists( 'UT_Footer_CSS' ) ) {	
    
    

}

