<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * deprecated file: with Version 4.2 the content has been moved into partials/hero-404.php
 *
 * @package unitedthemes
 */
?>

<?php get_header(); ?>
	
    
<div class="ut-scroll-up-waypoint-wrap">
    <div class="ut-scroll-up-waypoint" data-section="section-to-main-content"></div>
</div>

<?php get_footer(); ?>